package com.example.prhultprize

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

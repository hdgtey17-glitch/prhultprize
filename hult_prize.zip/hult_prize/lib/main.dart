import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'theme/app_theme.dart';
import 'screens/auth_screens.dart';
import 'screens/main_navigation.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://jepkuyijukcvganahcgn.supabase.co',
    anonKey: 'sb_publishable_25FLIfrEkgrid6koF8kxmg_FZvn5qwl',
  );

  runApp(const HultPrizePRApp());
}

class HultPrizePRApp extends StatelessWidget {
  const HultPrizePRApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Hult Prize PR',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      locale: const Locale('ar', 'EG'),
      supportedLocales: const [Locale('ar', 'EG')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    final session = Supabase.instance.client.auth.currentSession;
    if (session == null) {
      return const LoginScreen();
    }
    return FutureBuilder(
      future: Supabase.instance.client
          .from('profiles')
          .select()
          .eq('id', session.user.id)
          .maybeSingle(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        final profile = snapshot.data;
        if (profile == null) return const LoginScreen();
        if (profile['status'] == 'pending') return const PendingApprovalScreen();
        if (profile['status'] == 'rejected') return const PendingApprovalScreen(isRejected: true);
        return MainNavigationScreen(isAdmin: profile['is_admin'] == true);
      },
    );
  }
}
/*import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'tasks_screen.dart';
import 'meetings_screen.dart';
import 'news_screen.dart';
import 'account_screens.dart';
import 'admin_screens.dart';

class MainNavigationScreen extends StatefulWidget {
  final bool isAdmin;
  const MainNavigationScreen({super.key, this.isAdmin = true});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final adminCard = Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.primaryMagenta.withValues(alpha: 0.3)),
      ),
      child: ListTile(
        leading: const CircleAvatar(
          backgroundColor: AppColors.primaryMagenta,
          child: Icon(Icons.admin_panel_settings_rounded, color: Colors.white),
        ),
        title: const Text('لوحة تحكم المشرف', style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: const Text('قبول الأعضاء، مراجعة المهام، وإحصائيات الحضور', style: TextStyle(fontSize: 12, color: AppColors.textGray)),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminDashboardScreen())),
      ),
    );

    final pages = [
      const HomeScreenContent(),
      const TasksScreen(),
      const MeetingsScreen(),
      MoreMenuScreen(adminSection: adminCard, isAdmin: widget.isAdmin),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const CircleAvatar(
              backgroundColor: AppColors.primaryMagenta,
              radius: 18,
              child: Icon(Icons.person, color: Colors.white, size: 20),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('أهلاً بيك 👋', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppColors.secondaryCyan.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    'عضو درجة 1 • 0 نقطة',
                    style: TextStyle(fontSize: 11, color: AppColors.secondaryCyan, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsScreen())),
            icon: const Icon(Icons.notifications_none_rounded, size: 28),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: pages[_currentIndex],
      floatingActionButton: widget.isAdmin
          ? Container(
              decoration: const BoxDecoration(gradient: AppColors.hultGradient, shape: BoxShape.circle),
              child: FloatingActionButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const UnifiedCreateScreen())),
                backgroundColor: Colors.transparent,
                elevation: 0,
                child: const Icon(Icons.add_rounded, color: Colors.white, size: 30),
              ),
            )
          : null,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        type: BottomNavigationBarType.fixed,
        backgroundColor: AppColors.surfaceWhite,
        selectedItemColor: AppColors.primaryMagenta,
        unselectedItemColor: AppColors.textGray,
        selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'الرئيسية'),
          BottomNavigationBarItem(icon: Icon(Icons.check_circle_outline_rounded), label: 'المهام'),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_month_rounded), label: 'الميتنجات'),
          BottomNavigationBarItem(icon: Icon(Icons.grid_view_rounded), label: 'المزيد'),
        ],
      ),
    );
  }
}

class HomeScreenContent extends StatelessWidget {
  const HomeScreenContent({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppColors.surfaceWhite,
              borderRadius: BorderRadius.circular(16),
              border: const Border(right: BorderSide(color: AppColors.secondaryCyan, width: 5)),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('الميتنج القادم', style: TextStyle(color: AppColors.secondaryCyan, fontWeight: FontWeight.bold, fontSize: 13)),
                SizedBox(height: 8),
                Text('لا توجد ميتنجات قادمة حالياً', style: TextStyle(color: AppColors.textGray, fontSize: 14)),
              ],
            ),
          ),
          const SizedBox(height: 24),
          const Text('مهامي العاجلة', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
            child: const Text('لا توجد مهام مطلوبة منك حالياً ✓', style: TextStyle(color: AppColors.textGray, fontSize: 14)),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('آخر الأخبار', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              TextButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NewsScreen())),
                child: const Text('عرض الكل', style: TextStyle(color: AppColors.secondaryCyan, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
            child: const Text('لا توجد أخبار منشورة بعد', style: TextStyle(color: AppColors.textGray, fontSize: 14)),
          ),
        ],
      ),
    );
  }
}*/

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../theme/app_theme.dart';
import 'tasks_screen.dart';
import 'meetings_screen.dart';
import 'news_screen.dart';
import 'account_screens.dart';
import 'admin_screens.dart';

class MainNavigationScreen extends StatefulWidget {
  final bool isAdmin;
  const MainNavigationScreen({super.key, this.isAdmin = true});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  final _supabase = Supabase.instance.client;
  int _currentIndex = 0;

  String userName = 'أهلاً بيك';
  String userGrade = 'درجة 1';
  int userPoints = 0;
  String? avatarUrl;

  dynamic nextMeeting;
  List<dynamic> urgentTasks = [];
  List<dynamic> latestNews = [];
  bool isHomeLoading = true;

  @override
  void initState() {
    super.initState();
    _loadUserAndHomeData();
  }

  Future<void> _loadUserAndHomeData() async {
    setState(() => isHomeLoading = true);
    try {
      final user = _supabase.auth.currentUser;
      String currentName = '';

      if (user != null) {
        final profile = await _supabase
            .from('profiles')
            .select()
            .eq('id', user.id)
            .maybeSingle();

        if (profile != null) {
          currentName = profile['name'] ?? '';
          userName = currentName.isNotEmpty ? currentName : 'أهلاً بيك';
          userGrade = profile['grade'] ?? 'درجة 1';
          userPoints = (profile['points'] ?? 0) as int;
          avatarUrl = profile['avatar_url'];
        }
      }

      final meetingsRes = await _supabase
          .from('meetings')
          .select()
          .order('created_at', ascending: false)
          .limit(1);

      final tasksRes = await _supabase
          .from('tasks')
          .select()
          .neq('status', 'معتمدة')
          .order('created_at', ascending: false)
          .limit(3);

      final newsRes = await _supabase
          .from('news')
          .select()
          .order('created_at', ascending: false)
          .limit(2);

      if (!mounted) return;
      setState(() {
        nextMeeting = meetingsRes.isNotEmpty ? meetingsRes.first : null;
        urgentTasks = List<dynamic>.from(tasksRes);
        latestNews = List<dynamic>.from(newsRes);
        isHomeLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => isHomeLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final adminCard = Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.primaryMagenta.withValues(alpha: 0.3)),
      ),
      child: ListTile(
        leading: const CircleAvatar(
          backgroundColor: AppColors.primaryMagenta,
          child: Icon(Icons.admin_panel_settings_rounded, color: Colors.white),
        ),
        title: const Text('لوحة تحكم المشرف', style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: const Text('قبول الأعضاء، مراجعة المهام، وإحصائيات الحضور', style: TextStyle(fontSize: 12, color: AppColors.textGray)),
        trailing: const Icon(Icons.chevron_right),
        onTap: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminDashboardScreen()));
          _loadUserAndHomeData();
        },
      ),
    );

    final pages = [
      HomeScreenContent(
        isAdmin: widget.isAdmin,
        nextMeeting: nextMeeting,
        urgentTasks: urgentTasks,
        latestNews: latestNews,
        isLoading: isHomeLoading,
        onRefresh: _loadUserAndHomeData,
        onSeeAllTasks: () => setState(() => _currentIndex = 1),
      ),
      TasksScreen(isAdmin: widget.isAdmin),
      MeetingsScreen(isAdmin: widget.isAdmin),
      MoreMenuScreen(
        adminSection: adminCard,
        isAdmin: widget.isAdmin,
        onProfileUpdated: _loadUserAndHomeData,
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: GestureDetector(
          onTap: () async {
            await Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen()));
            _loadUserAndHomeData();
          },
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: AppColors.primaryMagenta,
                radius: 18,
                backgroundImage: avatarUrl != null && avatarUrl!.isNotEmpty ? NetworkImage(avatarUrl!) : null,
                child: avatarUrl == null || avatarUrl!.isEmpty
                    ? const Icon(Icons.person, color: Colors.white, size: 20)
                    : null,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'أهلاً يا ${userName.split(' ').first} 👋',
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppColors.secondaryCyan.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        'عضو $userGrade • $userPoints نقطة',
                        style: const TextStyle(fontSize: 11, color: AppColors.secondaryCyan, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          IconButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsScreen())),
            icon: const Icon(Icons.notifications_none_rounded, size: 28),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: pages[_currentIndex],
      floatingActionButton: widget.isAdmin
          ? Container(
              decoration: const BoxDecoration(gradient: AppColors.hultGradient, shape: BoxShape.circle),
              child: FloatingActionButton(
                onPressed: () async {
                  final created = await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const UnifiedCreateScreen()),
                  );
                  if (created == true) {
                    _loadUserAndHomeData();
                  }
                },
                backgroundColor: Colors.transparent,
                elevation: 0,
                child: const Icon(Icons.add_rounded, color: Colors.white, size: 30),
              ),
            )
          : null,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        type: BottomNavigationBarType.fixed,
        backgroundColor: AppColors.surfaceWhite,
        selectedItemColor: AppColors.primaryMagenta,
        unselectedItemColor: AppColors.textGray,
        selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'الرئيسية'),
          BottomNavigationBarItem(icon: Icon(Icons.check_circle_outline_rounded), label: 'المهام'),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_month_rounded), label: 'الميتنجات'),
          BottomNavigationBarItem(icon: Icon(Icons.grid_view_rounded), label: 'المزيد'),
        ],
      ),
    );
  }
}

class HomeScreenContent extends StatelessWidget {
  final bool isAdmin;
  final dynamic nextMeeting;
  final List<dynamic> urgentTasks;
  final List<dynamic> latestNews;
  final bool isLoading;
  final Future<void> Function() onRefresh;
  final VoidCallback onSeeAllTasks;

  const HomeScreenContent({
    super.key,
    this.isAdmin = false,
    this.nextMeeting,
    this.urgentTasks = const [],
    this.latestNews = const [],
    this.isLoading = false,
    required this.onRefresh,
    required this.onSeeAllTasks,
  });

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Center(child: CircularProgressIndicator(color: AppColors.primaryMagenta));
    }

    return RefreshIndicator(
      onRefresh: onRefresh,
      color: AppColors.primaryMagenta,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.surfaceWhite,
                borderRadius: BorderRadius.circular(16),
                border: const Border(right: BorderSide(color: AppColors.secondaryCyan, width: 5)),
              ),
              child: nextMeeting == null
                  ? const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('الميتنج القادم', style: TextStyle(color: AppColors.secondaryCyan, fontWeight: FontWeight.bold, fontSize: 13)),
                        SizedBox(height: 8),
                        Text('لا توجد ميتنجات قادمة حالياً', style: TextStyle(color: AppColors.textGray, fontSize: 14)),
                      ],
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('الميتنج القادم', style: TextStyle(color: AppColors.secondaryCyan, fontWeight: FontWeight.bold, fontSize: 13)),
                        const SizedBox(height: 6),
                        Text(nextMeeting['title'] ?? '', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            const Icon(Icons.access_time_rounded, size: 16, color: AppColors.textGray),
                            const SizedBox(width: 4),
                            Text(nextMeeting['meeting_time'] ?? '', style: const TextStyle(color: AppColors.textGray, fontSize: 13)),
                            const SizedBox(width: 14),
                            const Icon(Icons.location_on_outlined, size: 16, color: AppColors.textGray),
                            const SizedBox(width: 4),
                            Expanded(
                              child: Text(
                                nextMeeting['location'] ?? '',
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(color: AppColors.textGray, fontSize: 13),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('مهامي العاجلة', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                if (urgentTasks.isNotEmpty)
                  TextButton(
                    onPressed: onSeeAllTasks,
                    child: const Text('عرض الكل', style: TextStyle(color: AppColors.primaryMagenta, fontWeight: FontWeight.bold)),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            if (urgentTasks.isEmpty)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                child: const Text('لا توجد مهام مطلوبة منك حالياً ✓', style: TextStyle(color: AppColors.textGray, fontSize: 14)),
              )
            else
              ...urgentTasks.map((task) => Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                    child: Row(
                      children: [
                        const Icon(Icons.bolt_rounded, color: AppColors.primaryMagenta),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(task['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                              Text('المسؤول: ${task['assigned_to'] ?? 'الجميع'} • ${task['deadline'] ?? ''}', style: const TextStyle(color: AppColors.textGray, fontSize: 12)),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: AppColors.primaryMagenta.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            '${task['points'] ?? 10} ن',
                            style: const TextStyle(color: AppColors.primaryMagenta, fontWeight: FontWeight.bold, fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                  )),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('آخر الأخبار', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                TextButton(
                  onPressed: () async {
                    await Navigator.push(context, MaterialPageRoute(builder: (_) => NewsScreen(isAdmin: isAdmin)));
                    onRefresh();
                  },
                  child: const Text('عرض الكل', style: TextStyle(color: AppColors.secondaryCyan, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (latestNews.isEmpty)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                child: const Text('لا توجد أخبار منشورة بعد', style: TextStyle(color: AppColors.textGray, fontSize: 14)),
              )
            else
              ...latestNews.map((item) => Container(
                    width: double.infinity,
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(item['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                        const SizedBox(height: 6),
                        Text(
                          item['body'] ?? '',
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: AppColors.textGray, fontSize: 13),
                        ),
                      ],
                    ),
                  )),
          ],
        ),
      ),
    );
  }
}
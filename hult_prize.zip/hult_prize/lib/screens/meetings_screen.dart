/*import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class MeetingsScreen extends StatefulWidget {
  const MeetingsScreen({super.key});

  @override
  State createState() => _MeetingsScreenState();
}

class _MeetingsScreenState extends State {
  bool showUpcoming = true;

  // قائمة الميتنجات (ستُملأ من Supabase)
  final List upcomingMeetings = [];
  final List pastMeetings = [];

  @override
  Widget build(BuildContext context) {
    final currentList = showUpcoming ? upcomingMeetings : pastMeetings;

    return Column(
      children: [
        Container(
          color: AppColors.surfaceWhite,
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => showUpcoming = true),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: showUpcoming ? AppColors.secondaryCyan : AppColors.background,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(
                      child: Text(
                        'الميتنجات القادمة',
                        style: TextStyle(color: showUpcoming ? Colors.white : AppColors.textGray, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => showUpcoming = false),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: !showUpcoming ? AppColors.secondaryCyan : AppColors.background,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(
                      child: Text(
                        'الميتنجات السابقة',
                        style: TextStyle(color: !showUpcoming ? Colors.white : AppColors.textGray, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: currentList.isEmpty
              ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.event_busy_rounded, size: 56, color: AppColors.textGray),
                      SizedBox(height: 12),
                      Text('لا توجد ميتنجات مجدولة حالياً', style: TextStyle(color: AppColors.textGray, fontSize: 15)),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: currentList.length,
                  itemBuilder: (context, index) => const SizedBox(),
                ),
        ),
      ],
    );
  }
}*/

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../theme/app_theme.dart';

class MeetingsScreen extends StatefulWidget {
  final bool isAdmin;
  const MeetingsScreen({super.key, this.isAdmin = false});

  @override
  State<MeetingsScreen> createState() => _MeetingsScreenState();
}

class _MeetingsScreenState extends State<MeetingsScreen> {
  final _supabase = Supabase.instance.client;
  List<dynamic> meetings = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchMeetings();
  }

  Future<void> _fetchMeetings() async {
    setState(() => isLoading = true);
    try {
      final res = await _supabase
          .from('meetings')
          .select()
          .order('created_at', ascending: false);
      if (mounted) {
        setState(() {
          meetings = List<dynamic>.from(res);
          isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> _voteAttendance(dynamic meeting, bool isGoing) async {
    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) return;

    List<String> going = List<String>.from(meeting['going_users'] ?? []);
    List<String> notGoing = List<String>.from(meeting['not_going_users'] ?? []);

    going.remove(userId);
    notGoing.remove(userId);

    if (isGoing) {
      going.add(userId);
    } else {
      notGoing.add(userId);
    }

    try {
      await _supabase.from('meetings').update({
        'going_users': going,
        'not_going_users': notGoing,
      }).eq('id', meeting['id']);
      _fetchMeetings();
    } catch (_) {}
  }

  Future<void> _deleteMeeting(String id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف الميتنج'),
        content: const Text('هل أنت متأكد من حذف هذا الميتنج نهائياً؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف', style: TextStyle(color: AppColors.statusRed)),
          ),
        ],
      ),
    );
    if (confirm != true) return;

    try {
      await _supabase.from('meetings').delete().eq('id', id);
      _fetchMeetings();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم حذف الميتنج بنجاح'), backgroundColor: AppColors.statusGreen),
      );
    } catch (_) {}
  }

  Future<void> _editMeetingDialog(dynamic meeting) async {
    final titleCtrl = TextEditingController(text: meeting['title'] ?? '');
    final timeCtrl = TextEditingController(text: meeting['meeting_time'] ?? '');
    final locCtrl = TextEditingController(text: meeting['location'] ?? '');

    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تعديل الميتنج'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: titleCtrl, decoration: const InputDecoration(hintText: 'عنوان الميتنج')),
            const SizedBox(height: 10),
            TextField(controller: timeCtrl, decoration: const InputDecoration(hintText: 'التاريخ والوقت')),
            const SizedBox(height: 10),
            TextField(controller: locCtrl, decoration: const InputDecoration(hintText: 'المكان أو الرابط')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () async {
              if (titleCtrl.text.trim().isEmpty) return;
              await _supabase.from('meetings').update({
                'title': titleCtrl.text.trim(),
                'meeting_time': timeCtrl.text.trim(),
                'location': locCtrl.text.trim(),
              }).eq('id', meeting['id']);
              if (ctx.mounted) Navigator.pop(ctx, true);
            },
            child: const Text('حفظ التعديل'),
          ),
        ],
      ),
    );

    if (saved == true) {
      _fetchMeetings();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم تعديل الميتنج بنجاح'), backgroundColor: AppColors.statusGreen),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentUserId = _supabase.auth.currentUser?.id;

    return isLoading
        ? const Center(child: CircularProgressIndicator(color: AppColors.secondaryCyan))
        : meetings.isEmpty
            ? const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.event_busy_rounded, size: 56, color: AppColors.textGray),
                    SizedBox(height: 12),
                    Text('لا توجد ميتنجات مجدولة حالياً', style: TextStyle(color: AppColors.textGray, fontSize: 15)),
                  ],
                ),
              )
            : RefreshIndicator(
                onRefresh: _fetchMeetings,
                child: ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: meetings.length,
                  separatorBuilder: (_, _) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final m = meetings[index];
                    final List going = m['going_users'] ?? [];
                    final List notGoing = m['not_going_users'] ?? [];
                    final bool amGoing = currentUserId != null && going.contains(currentUserId);
                    final bool amNotGoing = currentUserId != null && notGoing.contains(currentUserId);

                    return Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppColors.surfaceWhite,
                        borderRadius: BorderRadius.circular(16),
                        border: const Border(right: BorderSide(color: AppColors.secondaryCyan, width: 4)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(m['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                              ),
                              if (widget.isAdmin) ...[
                                IconButton(
                                  icon: const Icon(Icons.edit_outlined, color: AppColors.secondaryCyan, size: 20),
                                  onPressed: () => _editMeetingDialog(m),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete_outline_rounded, color: AppColors.statusRed, size: 20),
                                  onPressed: () => _deleteMeeting(m['id']),
                                ),
                              ],
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              const Icon(Icons.access_time_rounded, size: 16, color: AppColors.textGray),
                              const SizedBox(width: 4),
                              Text(m['meeting_time'] ?? '', style: const TextStyle(color: AppColors.textGray, fontSize: 13)),
                              const SizedBox(width: 16),
                              const Icon(Icons.location_on_outlined, size: 16, color: AppColors.textGray),
                              const SizedBox(width: 4),
                              Expanded(
                                child: Text(m['location'] ?? '', overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.textGray, fontSize: 13)),
                              ),
                            ],
                          ),
                          const SizedBox(height: 14),
                          Row(
                            children: [
                              Expanded(
                                child: ElevatedButton.icon(
                                  onPressed: () => _voteAttendance(m, true),
                                  icon: const Icon(Icons.check_circle_outline, size: 18),
                                  label: Text('جاي (${going.length})'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: amGoing ? AppColors.statusGreen : AppColors.background,
                                    foregroundColor: amGoing ? Colors.white : AppColors.textDark,
                                    minimumSize: const Size(0, 40),
                                    elevation: 0,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: ElevatedButton.icon(
                                  onPressed: () => _voteAttendance(m, false),
                                  icon: const Icon(Icons.cancel_outlined, size: 18),
                                  label: Text('مش جاي (${notGoing.length})'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: amNotGoing ? AppColors.statusRed : AppColors.background,
                                    foregroundColor: amNotGoing ? Colors.white : AppColors.textDark,
                                    minimumSize: const Size(0, 40),
                                    elevation: 0,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                ),
              );
  }
}
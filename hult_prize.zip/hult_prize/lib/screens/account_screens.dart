/*import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'auth_screens.dart';
import 'community_screens.dart';
import 'news_screen.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List notifications = [];

    return Scaffold(
      appBar: AppBar(title: const Text('الإشعارات')),
      body: notifications.isEmpty
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.notifications_off_outlined, size: 56, color: AppColors.textGray),
                  SizedBox(height: 12),
                  Text('لا توجد إشعارات جديدة', style: TextStyle(color: AppColors.textGray, fontSize: 15)),
                ],
              ),
            )
          : ListView.builder(itemCount: notifications.length, itemBuilder: (_, __) => const SizedBox()),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  final String userName;
  final String userMajor;
  final String userRole;
  final int points;

  const ProfileScreen({
    super.key,
    this.userName = 'اسم العضو',
    this.userMajor = 'التخصص',
    this.userRole = 'عضو في القسم',
    this.points = 0,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الملف الشخصي')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(gradient: AppColors.hultGradient, borderRadius: BorderRadius.circular(20)),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 38,
                    backgroundColor: Colors.white,
                    child: Text(userName.substring(0, 1), style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: AppColors.primaryMagenta)),
                  ),
                  const SizedBox(height: 12),
                  Text(userName, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                  Text('$userMajor • $userRole', style: const TextStyle(color: Colors.white70, fontSize: 13)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  const Column(
                    children: [
                      Text('0', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppColors.primaryMagenta)),
                      Text('مهمة منجزة', style: TextStyle(color: AppColors.textGray, fontSize: 12)),
                    ],
                  ),
                  const Column(
                    children: [
                      Text('0%', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppColors.secondaryCyan)),
                      Text('نسبة الحضور', style: TextStyle(color: AppColors.textGray, fontSize: 12)),
                    ],
                  ),
                  Column(
                    children: [
                      Text('$points', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppColors.accentPurple)),
                      const Text('إجمالي النقاط', style: TextStyle(color: AppColors.textGray, fontSize: 12)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            OutlinedButton.icon(
              onPressed: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                  (route) => false,
                );
              },
              icon: const Icon(Icons.logout_rounded, color: AppColors.statusRed),
              label: const Text('تسجيل الخروج', style: TextStyle(color: AppColors.statusRed, fontWeight: FontWeight.bold)),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(double.infinity, 50),
                side: const BorderSide(color: AppColors.statusRed),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class MoreMenuScreen extends StatelessWidget {
  final Widget? adminSection;
  final bool isAdmin;
  const MoreMenuScreen({super.key, this.adminSection, this.isAdmin = true});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _menuTile(context, 'لوحة النشطاء ونقاطي', 'شوف ترتيبك ورصيد نقاطك للترقية', Icons.emoji_events_rounded, AppColors.primaryMagenta, const LeaderboardScreen()),
        _menuTile(context, 'الجروبات', 'جروبات العمل الفرعية ومهامها', Icons.groups_rounded, AppColors.secondaryCyan, const GroupsScreen()),
        _menuTile(context, 'دليل الأعضاء', 'بيانات وتخصصات أعضاء القسم', Icons.contact_page_rounded, AppColors.accentPurple, MembersDirectoryScreen(isAdmin: isAdmin)),
        _menuTile(context, 'أخبار القسم', 'كل الإعلانات والتحديثات الرسمية', Icons.campaign_rounded, AppColors.primaryMagenta, const NewsScreen()),
        _menuTile(context, 'الملف الشخصي', 'بياناتك وإحصائياتك', Icons.person_rounded, AppColors.secondaryCyan, const ProfileScreen()),
        if (isAdmin && adminSection != null) ...[
          const SizedBox(height: 16),
          const Text('أدوات المشرف (Admin)', style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.textGray)),
          const SizedBox(height: 8),
          adminSection!,
        ],
      ],
    );
  }

  Widget _menuTile(BuildContext context, String title, String sub, IconData icon, Color color, Widget page) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: color.withValues(alpha: 0.12), child: Icon(icon, color: color)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(sub, style: const TextStyle(fontSize: 12, color: AppColors.textGray)),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => page)),
      ),
    );
  }
}*/


import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../theme/app_theme.dart';
import 'auth_screens.dart';
import 'community_screens.dart';
import 'news_screen.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  final _supabase = Supabase.instance.client;
  List<dynamic> notifications = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchNotifications();
  }

  Future<void> _fetchNotifications() async {
    setState(() => isLoading = true);
    try {
      final newsRes = await _supabase
          .from('news')
          .select()
          .order('created_at', ascending: false)
          .limit(5);

      final meetingsRes = await _supabase
          .from('meetings')
          .select()
          .order('created_at', ascending: false)
          .limit(5);

      final tasksRes = await _supabase
          .from('tasks')
          .select()
          .order('created_at', ascending: false)
          .limit(5);

      final List<dynamic> combined = [];

      for (final n in newsRes) {
        combined.add({
          'type': 'news',
          'title': 'خبر جديد: ${n['title'] ?? ''}',
          'subtitle': n['body'] ?? '',
          'created_at': n['created_at'] ?? '',
        });
      }

      for (final m in meetingsRes) {
        combined.add({
          'type': 'meeting',
          'title': 'ميتنج مجدول: ${m['title'] ?? ''}',
          'subtitle': '${m['meeting_time'] ?? ''} • ${m['location'] ?? ''}',
          'created_at': m['created_at'] ?? '',
        });
      }

      for (final t in tasksRes) {
        combined.add({
          'type': 'task',
          'title': 'مهمة جديدة: ${t['title'] ?? ''}',
          'subtitle': 'المسؤول: ${t['assigned_to'] ?? 'الجميع'} • ${t['points'] ?? 10} نقطة',
          'created_at': t['created_at'] ?? '',
        });
      }

      // ترتيب كل الإشعارات من الأحدث للأقدم
      combined.sort((a, b) => (b['created_at'] as String).compareTo(a['created_at'] as String));

      if (mounted) {
        setState(() {
          notifications = combined;
          isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإشعارات')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primaryMagenta))
          : notifications.isEmpty
              ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.notifications_off_outlined, size: 56, color: AppColors.textGray),
                      SizedBox(height: 12),
                      Text('لا توجد إشعارات جديدة', style: TextStyle(color: AppColors.textGray, fontSize: 15)),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _fetchNotifications,
                  color: AppColors.primaryMagenta,
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: notifications.length,
                    separatorBuilder: (_, _) => const SizedBox(height: 10),
                    itemBuilder: (context, index) {
                      final item = notifications[index];
                      final String type = item['type'] ?? 'news';

                      IconData icon;
                      Color color;
                      if (type == 'meeting') {
                        icon = Icons.calendar_month_rounded;
                        color = AppColors.secondaryCyan;
                      } else if (type == 'task') {
                        icon = Icons.bolt_rounded;
                        color = AppColors.statusAmber;
                      } else {
                        icon = Icons.campaign_rounded;
                        color = AppColors.primaryMagenta;
                      }

                      return Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceWhite,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CircleAvatar(
                              backgroundColor: color.withValues(alpha: 0.12),
                              child: Icon(icon, color: color, size: 22),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item['title'] ?? '',
                                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    item['subtitle'] ?? '',
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(color: AppColors.textGray, fontSize: 12),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _supabase = Supabase.instance.client;
  bool isLoading = true;
  bool isUploadingAvatar = false;
  dynamic profile;

  @override
  void initState() {
    super.initState();
    _fetchProfile();
  }

  Future<void> _fetchProfile() async {
    try {
      final user = _supabase.auth.currentUser;
      if (user != null) {
        final res = await _supabase
            .from('profiles')
            .select()
            .eq('id', user.id)
            .maybeSingle();
        if (mounted) {
          setState(() {
            profile = res;
            isLoading = false;
          });
        }
      } else {
        if (mounted) setState(() => isLoading = false);
      }
    } catch (e) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> _changeProfilePicture() async {
    final user = _supabase.auth.currentUser;
    if (user == null) return;

    final picked = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      imageQuality: 70,
    );
    if (picked == null) return;

    setState(() => isUploadingAvatar = true);
    try {
      final file = File(picked.path);
      final filePath = '${user.id}.jpg';

      await _supabase.storage.from('avatars').upload(
            filePath,
            file,
            fileOptions: const FileOptions(upsert: true),
          );

      final baseUrl = _supabase.storage.from('avatars').getPublicUrl(filePath);
      final freshUrl = '$baseUrl?t=${DateTime.now().millisecondsSinceEpoch}';

      await _supabase
          .from('profiles')
          .update({'avatar_url': freshUrl})
          .eq('id', user.id);

      await _fetchProfile();

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تم تحديث صورتك الشخصية بنجاح!'),
          backgroundColor: AppColors.statusGreen,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('حدث خطأ أثناء رفع الصورة: $e'),
          backgroundColor: AppColors.statusRed,
        ),
      );
    } finally {
      if (mounted) setState(() => isUploadingAvatar = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final String userName = profile != null ? (profile['name'] ?? 'عضو الفريق') : 'عضو الفريق';
    final String userMajor = profile != null ? (profile['major'] ?? 'التخصص') : 'التخصص';
    final String userRole = profile != null ? (profile['role'] ?? 'عضو في القسم') : 'عضو في القسم';
    final int points = profile != null ? ((profile['points'] ?? 0) as int) : 0;
    final String? avatarUrl = profile != null ? profile['avatar_url'] : null;

    return Scaffold(
      appBar: AppBar(title: const Text('الملف الشخصي')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primaryMagenta))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(gradient: AppColors.hultGradient, borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      children: [
                        GestureDetector(
                          onTap: isUploadingAvatar ? null : _changeProfilePicture,
                          child: Stack(
                            alignment: Alignment.bottomRight,
                            children: [
                              CircleAvatar(
                                radius: 42,
                                backgroundColor: Colors.white,
                                backgroundImage: avatarUrl != null && avatarUrl.isNotEmpty
                                    ? NetworkImage(avatarUrl)
                                    : null,
                                child: isUploadingAvatar
                                    ? const CircularProgressIndicator(color: AppColors.primaryMagenta)
                                    : (avatarUrl == null || avatarUrl.isEmpty
                                        ? Text(
                                            userName.isNotEmpty ? userName.substring(0, 1) : 'ع',
                                            style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: AppColors.primaryMagenta),
                                          )
                                        : null),
                              ),
                              Container(
                                padding: const EdgeInsets.all(6),
                                decoration: const BoxDecoration(
                                  color: AppColors.secondaryCyan,
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(Icons.camera_alt_rounded, color: Colors.white, size: 16),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 6),
                        const Text('اضغط على الصورة لتغييرها', style: TextStyle(color: Colors.white70, fontSize: 11)),
                        const SizedBox(height: 10),
                        Text(userName, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                        Text('$userMajor • $userRole', style: const TextStyle(color: Colors.white70, fontSize: 13)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Column(
                          children: [
                            Text(profile != null ? (profile['grade'] ?? 'درجة 1') : 'درجة 1', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.primaryMagenta)),
                            const SizedBox(height: 4),
                            const Text('المستوى الحالي', style: TextStyle(color: AppColors.textGray, fontSize: 12)),
                          ],
                        ),
                        Column(
                          children: [
                            Text('$points', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppColors.accentPurple)),
                            const Text('إجمالي النقاط', style: TextStyle(color: AppColors.textGray, fontSize: 12)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  OutlinedButton.icon(
                    onPressed: () async {
                      await _supabase.auth.signOut();
                      if (!context.mounted) return;
                      Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(builder: (_) => const LoginScreen()),
                        (route) => false,
                      );
                    },
                    icon: const Icon(Icons.logout_rounded, color: AppColors.statusRed),
                    label: const Text('تسجيل الخروج', style: TextStyle(color: AppColors.statusRed, fontWeight: FontWeight.bold)),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(double.infinity, 50),
                      side: const BorderSide(color: AppColors.statusRed),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}

class MoreMenuScreen extends StatelessWidget {
  final Widget? adminSection;
  final bool isAdmin;
  final VoidCallback? onProfileUpdated;

  const MoreMenuScreen({
    super.key,
    this.adminSection,
    this.isAdmin = true,
    this.onProfileUpdated,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _menuTile(context, 'لوحة النشطاء ونقاطي', 'شوف ترتيبك ورصيد نقاطك للترقية', Icons.emoji_events_rounded, AppColors.primaryMagenta, const LeaderboardScreen()),
        _menuTile(context, 'الجروبات', 'جروبات العمل الفرعية ومهامها', Icons.groups_rounded, AppColors.secondaryCyan, GroupsScreen(isAdmin: isAdmin)),
        _menuTile(context, 'دليل الأعضاء', 'بيانات وتخصصات أعضاء القسم', Icons.contact_page_rounded, AppColors.accentPurple, MembersDirectoryScreen(isAdmin: isAdmin)),
        _menuTile(context, 'أخبار القسم', 'كل الإعلانات والتحديثات الرسمية', Icons.campaign_rounded, AppColors.primaryMagenta, NewsScreen(isAdmin: isAdmin)),
        _menuTile(context, 'الملف الشخصي', 'بياناتك وإحصائياتك', Icons.person_rounded, AppColors.secondaryCyan, const ProfileScreen(), refreshOnBack: true),
        if (isAdmin && adminSection != null) ...[
          const SizedBox(height: 16),
          const Text('أدوات المشرف (Admin)', style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.textGray)),
          const SizedBox(height: 8),
          adminSection!,
        ],
      ],
    );
  }

  Widget _menuTile(BuildContext context, String title, String sub, IconData icon, Color color, Widget page, {bool refreshOnBack = false}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: color.withValues(alpha: 0.12), child: Icon(icon, color: color)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(sub, style: const TextStyle(fontSize: 12, color: AppColors.textGray)),
        trailing: const Icon(Icons.chevron_right),
        onTap: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
          if (refreshOnBack && onProfileUpdated != null) {
            onProfileUpdated!();
          }
        },
      ),
    );
  }
}
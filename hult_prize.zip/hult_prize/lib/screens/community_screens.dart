/*import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class GroupsScreen extends StatelessWidget {
  const GroupsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List groups = [];

    return Scaffold(
      appBar: AppBar(title: const Text('جروباتي')),
      body: groups.isEmpty
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.groups_outlined, size: 56, color: AppColors.textGray),
                  SizedBox(height: 12),
                  Text('لم يتم إنشاء جروبات بعد', style: TextStyle(color: AppColors.textGray, fontSize: 15)),
                ],
              ),
            )
          : ListView.builder(itemCount: groups.length, itemBuilder: (_, __) => const SizedBox()),
    );
  }
}

class LeaderboardScreen extends StatelessWidget {
  final int myPoints;
  final String myGrade;
  const LeaderboardScreen({super.key, this.myPoints = 0, this.myGrade = 'عضو درجة 1'});

  @override
  Widget build(BuildContext context) {
    final List members = [];

    return Scaffold(
      appBar: AppBar(title: const Text('لوحة النشطاء ونقاطي')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: AppColors.hultGradient,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('رصيد نقاطك الحالي', style: TextStyle(color: Colors.white70, fontSize: 13)),
                          const SizedBox(height: 4),
                          Text('$myPoints نقطة', style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(myGrade, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: LinearProgressIndicator(
                      value: (myPoints % 100) / 100,
                      minHeight: 8,
                      backgroundColor: Colors.white.withValues(alpha: 0.25),
                      valueColor: const AlwaysStoppedAnimation(Colors.white),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text('أنجز المهام واحضر الميتنجات لجمع النقاط والترقية 🚀', style: TextStyle(color: Colors.white, fontSize: 12)),
                ],
              ),
            ),
            const SizedBox(height: 24),
            if (members.isEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 40),
                child: Text('سيظهر ترتيب الأعضاء هنا بمجرد بدء النشاط', style: TextStyle(color: AppColors.textGray)),
              ),
          ],
        ),
      ),
    );
  }
}

class MembersDirectoryScreen extends StatefulWidget {
  final bool isAdmin;
  const MembersDirectoryScreen({super.key, this.isAdmin = true});

  @override
  State<MembersDirectoryScreen> createState() => _MembersDirectoryScreenState();
}

class _MembersDirectoryScreenState extends State<MembersDirectoryScreen> {
  final List directory = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('دليل الأعضاء')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'ابحث بالاسم أو التخصص...',
                fillColor: AppColors.surfaceWhite,
                prefixIcon: const Icon(Icons.search, color: AppColors.secondaryCyan),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              ),
            ),
          ),
          Expanded(
            child: directory.isEmpty
                ? const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.people_outline_rounded, size: 56, color: AppColors.textGray),
                        SizedBox(height: 12),
                        Text('لا يوجد أعضاء مسجلون بعد', style: TextStyle(color: AppColors.textGray, fontSize: 15)),
                      ],
                    ),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: directory.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (context, index) {
                      final member = directory[index];
                      final memberIsAdmin = member['is_admin'] == true;

                      return Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                        child: Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: AppColors.secondaryCyan.withValues(alpha: 0.15),
                              child: Text((member['name'] ?? 'ع').substring(0, 1), style: const TextStyle(color: AppColors.secondaryCyan, fontWeight: FontWeight.bold)),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(member['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                                  Text('${member['major'] ?? ''} • ${member['role'] ?? ''}', style: const TextStyle(color: AppColors.textGray, fontSize: 12)),
                                ],
                              ),
                            ),
                            if (widget.isAdmin)
                              TextButton.icon(
                                onPressed: () {},
                                icon: Icon(
                                  memberIsAdmin ? Icons.verified_user : Icons.admin_panel_settings_outlined,
                                  size: 18,
                                  color: memberIsAdmin ? AppColors.primaryMagenta : AppColors.secondaryCyan,
                                ),
                                label: Text(
                                  memberIsAdmin ? 'مشرف' : 'ترقية لمشرف',
                                  style: TextStyle(
                                    color: memberIsAdmin ? AppColors.primaryMagenta : AppColors.secondaryCyan,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}*/

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../theme/app_theme.dart';

class GroupsScreen extends StatefulWidget {
  final bool isAdmin;
  const GroupsScreen({super.key, this.isAdmin = false});

  @override
  State<GroupsScreen> createState() => _GroupsScreenState();
}

class _GroupsScreenState extends State<GroupsScreen> {
  final _supabase = Supabase.instance.client;
  List<dynamic> groups = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchGroups();
  }

  Future<void> _fetchGroups() async {
    setState(() => isLoading = true);
    try {
      final res = await _supabase
          .from('groups')
          .select()
          .order('created_at', ascending: false);
      if (mounted) {
        setState(() {
          groups = List<dynamic>.from(res);
          isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> _deleteGroup(String id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف الجروب'),
        content: const Text('هل أنت متأكد من حذف هذا الجروب نهائياً؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف', style: TextStyle(color: AppColors.statusRed)),
          ),
        ],
      ),
    );
    if (confirm != true) return;

    await _supabase.from('groups').delete().eq('id', id);
    _fetchGroups();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم حذف الجروب بنجاح'), backgroundColor: AppColors.statusGreen),
    );
  }

  Future<void> _editGroupDialog(dynamic group) async {
    final nameCtrl = TextEditingController(text: group['name'] ?? '');
    final descCtrl = TextEditingController(text: group['description'] ?? '');

    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تعديل الجروب'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: nameCtrl, decoration: const InputDecoration(hintText: 'اسم الجروب')),
            const SizedBox(height: 10),
            TextField(controller: descCtrl, maxLines: 2, decoration: const InputDecoration(hintText: 'وصف الجروب')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () async {
              if (nameCtrl.text.trim().isEmpty) return;
              await _supabase.from('groups').update({
                'name': nameCtrl.text.trim(),
                'description': descCtrl.text.trim(),
              }).eq('id', group['id']);
              if (ctx.mounted) Navigator.pop(ctx, true);
            },
            child: const Text('حفظ التعديل'),
          ),
        ],
      ),
    );

    if (saved == true) {
      _fetchGroups();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم تعديل الجروب بنجاح'), backgroundColor: AppColors.statusGreen),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('جروبات العمل')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.secondaryCyan))
          : groups.isEmpty
              ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.groups_outlined, size: 56, color: AppColors.textGray),
                      SizedBox(height: 12),
                      Text('لم يتم إنشاء جروبات بعد', style: TextStyle(color: AppColors.textGray, fontSize: 15)),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _fetchGroups,
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: groups.length,
                    separatorBuilder: (_, _) => const SizedBox(height: 12),
                    itemBuilder: (context, index) {
                      final group = groups[index];
                      final List memberIds = group['member_ids'] ?? [];

                      return GestureDetector(
                        onTap: () async {
                          await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => GroupDetailsScreen(
                                group: group,
                                isAdmin: widget.isAdmin,
                              ),
                            ),
                          );
                          _fetchGroups();
                        },
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: AppColors.surfaceWhite,
                            borderRadius: BorderRadius.circular(16),
                            border: const Border(right: BorderSide(color: AppColors.secondaryCyan, width: 4)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Icon(Icons.groups_rounded, color: AppColors.secondaryCyan),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      group['name'] ?? '',
                                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                    ),
                                  ),
                                  if (widget.isAdmin) ...[
                                    IconButton(
                                      icon: const Icon(Icons.edit_outlined, color: AppColors.secondaryCyan, size: 20),
                                      onPressed: () => _editGroupDialog(group),
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.delete_outline_rounded, color: AppColors.statusRed, size: 20),
                                      onPressed: () => _deleteGroup(group['id']),
                                    ),
                                  ],
                                ],
                              ),
                              if ((group['description'] ?? '').toString().isNotEmpty) ...[
                                const SizedBox(height: 6),
                                Text(
                                  group['description'],
                                  style: const TextStyle(color: AppColors.textGray, fontSize: 13),
                                ),
                              ],
                              const SizedBox(height: 10),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: AppColors.secondaryCyan.withValues(alpha: 0.12),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Text(
                                      '${memberIds.length} أعضاء',
                                      style: const TextStyle(
                                        color: AppColors.secondaryCyan,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ),
                                  const Text(
                                    'اضغط للتفاصيل والأعضاء ←',
                                    style: TextStyle(color: AppColors.textGray, fontSize: 12),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}

class GroupDetailsScreen extends StatefulWidget {
  final dynamic group;
  final bool isAdmin;

  const GroupDetailsScreen({
    super.key,
    required this.group,
    this.isAdmin = false,
  });

  @override
  State<GroupDetailsScreen> createState() => _GroupDetailsScreenState();
}

class _GroupDetailsScreenState extends State<GroupDetailsScreen> {
  final _supabase = Supabase.instance.client;
  bool isLoading = true;
  List<String> memberIds = [];
  List<dynamic> groupMembers = [];
  List<dynamic> groupTasks = [];

  @override
  void initState() {
    super.initState();
    memberIds = List<String>.from(widget.group['member_ids'] ?? []);
    _loadGroupDetails();
  }

  Future<void> _loadGroupDetails() async {
    setState(() => isLoading = true);
    try {
      // جلب كل الأعضاء المقبولين لتحديد أعضاء الجروب
      final profilesRes = await _supabase
          .from('profiles')
          .select()
          .eq('status', 'approved');

      final allApproved = List<dynamic>.from(profilesRes);
      final filteredMembers = allApproved
          .where((p) => memberIds.contains(p['id'].toString()))
          .toList();

      // جلب المهام المعيّنة باسم هذا الجروب
      final groupName = (widget.group['name'] ?? '').toString();
      final tasksRes = await _supabase
          .from('tasks')
          .select()
          .ilike('assigned_to', '%$groupName%')
          .order('created_at', ascending: false);

      if (mounted) {
        setState(() {
          groupMembers = filteredMembers;
          groupTasks = List<dynamic>.from(tasksRes);
          isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> _manageMembersDialog() async {
    final profilesRes = await _supabase
        .from('profiles')
        .select()
        .eq('status', 'approved')
        .order('name', ascending: true);

    final allMembers = List<dynamic>.from(profilesRes);
    final selectedSet = Set<String>.from(memberIds);

    if (!mounted) return;
    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('إدارة أعضاء الجروب'),
          content: SizedBox(
            width: double.maxFinite,
            height: 320,
            child: allMembers.isEmpty
                ? const Center(child: Text('لا يوجد أعضاء مقبولون حالياً'))
                : ListView.builder(
                    itemCount: allMembers.length,
                    itemBuilder: (context, idx) {
                      final m = allMembers[idx];
                      final mId = m['id'].toString();
                      final isChecked = selectedSet.contains(mId);

                      return CheckboxListTile(
                        value: isChecked,
                        activeColor: AppColors.secondaryCyan,
                        title: Text(m['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        subtitle: Text(m['role'] ?? '', style: const TextStyle(fontSize: 12)),
                        onChanged: (val) {
                          setDialogState(() {
                            if (val == true) {
                              selectedSet.add(mId);
                            } else {
                              selectedSet.remove(mId);
                            }
                          });
                        },
                      );
                    },
                  ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            ElevatedButton(
              onPressed: () async {
                final updatedList = selectedSet.toList();
                await _supabase
                    .from('groups')
                    .update({'member_ids': updatedList})
                    .eq('id', widget.group['id']);
                memberIds = updatedList;
                if (ctx.mounted) Navigator.pop(ctx, true);
              },
              child: const Text('حفظ الأعضاء'),
            ),
          ],
        ),
      ),
    );

    if (saved == true) {
      _loadGroupDetails();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم تحديث أعضاء الجروب بنجاح'), backgroundColor: AppColors.statusGreen),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.group['name'] ?? 'تفاصيل الجروب')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.secondaryCyan))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: AppColors.surfaceWhite,
                      borderRadius: BorderRadius.circular(16),
                      border: const Border(right: BorderSide(color: AppColors.secondaryCyan, width: 4)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(widget.group['name'] ?? '', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        if ((widget.group['description'] ?? '').toString().isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Text(widget.group['description'], style: const TextStyle(color: AppColors.textGray, fontSize: 14)),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('أعضاء الجروب (${groupMembers.length})', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                      if (widget.isAdmin)
                        TextButton.icon(
                          onPressed: _manageMembersDialog,
                          icon: const Icon(Icons.person_add_alt_1_rounded, color: AppColors.secondaryCyan, size: 20),
                          label: const Text('تعديل الأعضاء', style: TextStyle(color: AppColors.secondaryCyan, fontWeight: FontWeight.bold)),
                        ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  if (groupMembers.isEmpty)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                      child: const Text('لم يتم إضافة أعضاء لهذا الجروب بعد', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textGray)),
                    )
                  else
                    ...groupMembers.map((m) => Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(14)),
                          child: Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: AppColors.secondaryCyan.withValues(alpha: 0.15),
                                child: Text((m['name'] ?? 'ع').substring(0, 1), style: const TextStyle(color: AppColors.secondaryCyan, fontWeight: FontWeight.bold)),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(m['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                                    Text(m['role'] ?? '', style: const TextStyle(color: AppColors.textGray, fontSize: 12)),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        )),
                  const SizedBox(height: 24),
                  Text('مهام الجروب (${groupTasks.length})', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  if (groupTasks.isEmpty)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                      child: const Text('لا توجد مهام مسندة لهذا الجروب حالياً', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textGray)),
                    )
                  else
                    ...groupTasks.map((t) => Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(14)),
                          child: Row(
                            children: [
                              const Icon(Icons.task_alt_rounded, color: AppColors.primaryMagenta),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(t['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                                    Text('الحالة: ${t['status'] ?? 'جديدة'} • التسليم: ${t['deadline'] ?? ''}', style: const TextStyle(color: AppColors.textGray, fontSize: 12)),
                                  ],
                                ),
                              ),
                              Text('${t['points'] ?? 10} ن', style: const TextStyle(color: AppColors.primaryMagenta, fontWeight: FontWeight.bold)),
                            ],
                          ),
                        )),
                ],
              ),
            ),
    );
  }
}

class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({super.key});

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen> {
  final _supabase = Supabase.instance.client;
  List<dynamic> members = [];
  int myPoints = 0;
  String myGrade = 'درجة 1';
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchLeaderboard();
  }

  Future<void> _fetchLeaderboard() async {
    setState(() => isLoading = true);
    try {
      final user = _supabase.auth.currentUser;
      final res = await _supabase
          .from('profiles')
          .select()
          .eq('status', 'approved')
          .order('points', ascending: false);

      if (mounted) {
        setState(() {
          members = List<dynamic>.from(res);
          if (user != null) {
            final me = members.where((m) => m['id'] == user.id).toList();
            if (me.isNotEmpty) {
              myPoints = (me.first['points'] ?? 0) as int;
              myGrade = me.first['grade'] ?? 'درجة 1';
            }
          }
          isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة النشطاء ونقاطي')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primaryMagenta))
          : RefreshIndicator(
              onRefresh: _fetchLeaderboard,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        gradient: AppColors.hultGradient,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text('رصيد نقاطك الحالي', style: TextStyle(color: Colors.white70, fontSize: 13)),
                                  const SizedBox(height: 4),
                                  Text('$myPoints نقطة', style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
                                ],
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(
                                  color: Colors.white.withValues(alpha: 0.2),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text('عضو $myGrade', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                              ),
                            ],
                          ),
                          const SizedBox(height: 18),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: LinearProgressIndicator(
                              value: (myPoints % 100) / 100,
                              minHeight: 8,
                              backgroundColor: Colors.white.withValues(alpha: 0.25),
                              valueColor: const AlwaysStoppedAnimation(Colors.white),
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Text('أنجز المهام واحضر الميتنجات لجمع النقاط والترقية 🚀', style: TextStyle(color: Colors.white, fontSize: 12)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    if (members.isEmpty)
                      const Padding(
                        padding: EdgeInsets.only(top: 40),
                        child: Text('سيظهر ترتيب الأعضاء هنا بمجرد بدء النشاط', style: TextStyle(color: AppColors.textGray)),
                      )
                    else
                      ...members.asMap().entries.map((entry) {
                        final rank = entry.key + 1;
                        final m = entry.value;
                        return Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                          child: Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: rank == 1
                                    ? AppColors.statusAmber.withValues(alpha: 0.2)
                                    : AppColors.background,
                                child: Text(
                                  '#$rank',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: rank == 1 ? AppColors.statusAmber : AppColors.textDark,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(m['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                                    Text(m['role'] ?? '', style: const TextStyle(color: AppColors.textGray, fontSize: 12)),
                                  ],
                                ),
                              ),
                              Text(
                                '${m['points'] ?? 0} نقطة',
                                style: const TextStyle(color: AppColors.primaryMagenta, fontWeight: FontWeight.bold, fontSize: 14),
                              ),
                            ],
                          ),
                        );
                      }),
                  ],
                ),
              ),
            ),
    );
  }
}

class MembersDirectoryScreen extends StatefulWidget {
  final bool isAdmin;
  const MembersDirectoryScreen({super.key, this.isAdmin = true});

  @override
  State<MembersDirectoryScreen> createState() => _MembersDirectoryScreenState();
}

class _MembersDirectoryScreenState extends State<MembersDirectoryScreen> {
  final _supabase = Supabase.instance.client;
  List<dynamic> directory = [];
  String searchQuery = '';
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchMembers();
  }

  Future<void> _fetchMembers() async {
    setState(() => isLoading = true);
    try {
      final res = await _supabase
          .from('profiles')
          .select()
          .eq('status', 'approved')
          .order('name', ascending: true);
      if (mounted) {
        setState(() {
          directory = List<dynamic>.from(res);
          isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> _toggleAdmin(String userId, bool currentIsAdmin) async {
    try {
      await _supabase
          .from('profiles')
          .update({'is_admin': !currentIsAdmin})
          .eq('id', userId);
      _fetchMembers();
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final filtered = directory.where((m) {
      final name = (m['name'] ?? '').toString().toLowerCase();
      final major = (m['major'] ?? '').toString().toLowerCase();
      return name.contains(searchQuery.toLowerCase()) || major.contains(searchQuery.toLowerCase());
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('دليل الأعضاء')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              onChanged: (val) => setState(() => searchQuery = val),
              decoration: InputDecoration(
                hintText: 'ابحث بالاسم أو التخصص...',
                fillColor: AppColors.surfaceWhite,
                prefixIcon: const Icon(Icons.search, color: AppColors.secondaryCyan),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              ),
            ),
          ),
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator(color: AppColors.secondaryCyan))
                : filtered.isEmpty
                    ? const Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.people_outline_rounded, size: 56, color: AppColors.textGray),
                            SizedBox(height: 12),
                            Text('لا يوجد أعضاء مسجلون بعد', style: TextStyle(color: AppColors.textGray, fontSize: 15)),
                          ],
                        ),
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: filtered.length,
                        separatorBuilder: (_, _) => const SizedBox(height: 10),
                        itemBuilder: (context, index) {
                          final member = filtered[index];
                          final memberIsAdmin = member['is_admin'] == true;

                          return Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                            child: Row(
                              children: [
                                CircleAvatar(
                                  backgroundColor: AppColors.secondaryCyan.withValues(alpha: 0.15),
                                  child: Text((member['name'] ?? 'ع').substring(0, 1), style: const TextStyle(color: AppColors.secondaryCyan, fontWeight: FontWeight.bold)),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(member['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                                      Text('${member['major'] ?? ''} • ${member['role'] ?? ''}', style: const TextStyle(color: AppColors.textGray, fontSize: 12)),
                                    ],
                                  ),
                                ),
                                if (widget.isAdmin)
                                  TextButton.icon(
                                    onPressed: () => _toggleAdmin(member['id'], memberIsAdmin),
                                    icon: Icon(
                                      memberIsAdmin ? Icons.verified_user : Icons.admin_panel_settings_outlined,
                                      size: 18,
                                      color: memberIsAdmin ? AppColors.primaryMagenta : AppColors.secondaryCyan,
                                    ),
                                    label: Text(
                                      memberIsAdmin ? 'مشرف' : 'ترقية لمشرف',
                                      style: TextStyle(
                                        color: memberIsAdmin ? AppColors.primaryMagenta : AppColors.secondaryCyan,
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
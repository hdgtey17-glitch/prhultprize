import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../theme/app_theme.dart';
import 'main_navigation.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  bool hidePassword = true;
  bool isLoading = false;

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: AppColors.statusRed),
    );
  }

  Future<void> _handleLogin() async {
    final email = emailController.text.trim();
    final password = passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      _showError('من فضلك أدخل البريد الإلكتروني وكلمة المرور');
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await Supabase.instance.client.auth.signInWithPassword(
        email: email,
        password: password,
      );

      final profile = await Supabase.instance.client
          .from('profiles')
          .select()
          .eq('id', res.user!.id)
          .single();

      if (!mounted) return;

      if (profile['status'] == 'pending') {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const PendingApprovalScreen()));
      } else if (profile['status'] == 'rejected') {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const PendingApprovalScreen(isRejected: true)));
      } else {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => MainNavigationScreen(isAdmin: profile['is_admin'] == true)),
        );
      }
    } on AuthException catch (e) {
      _showError(e.message == 'Invalid login credentials'
          ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
          : e.message);
    } catch (e) {
      _showError('حدث خطأ أثناء تسجيل الدخول، تأكد من الاتصال بالإنترنت');
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surfaceWhite,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 40),
              Container(
                width: 85,
                height: 85,
                decoration: BoxDecoration(color: AppColors.primaryMagenta, borderRadius: BorderRadius.circular(22)),
                child: const Center(
                  child: Text('H', style: TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.w900)),
                ),
              ),
              const SizedBox(height: 16),
              const Text('HULT PRIZE PR', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
              const SizedBox(height: 8),
              const Text('أهلاً بيك في فريق PR 👋', style: TextStyle(fontSize: 16, color: AppColors.textGray)),
              const SizedBox(height: 40),
              TextField(
                controller: emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  hintText: 'البريد الإلكتروني',
                  prefixIcon: Icon(Icons.email_outlined, color: AppColors.textGray),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: passwordController,
                obscureText: hidePassword,
                decoration: InputDecoration(
                  hintText: 'كلمة المرور',
                  prefixIcon: const Icon(Icons.lock_outline, color: AppColors.textGray),
                  suffixIcon: IconButton(
                    icon: Icon(hidePassword ? Icons.visibility_off_outlined : Icons.visibility_outlined, color: AppColors.textGray),
                    onPressed: () => setState(() => hidePassword = !hidePassword),
                  ),
                ),
              ),
              const SizedBox(height: 28),
              ElevatedButton(
                onPressed: isLoading ? null : _handleLogin,
                child: isLoading
                    ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Text('تسجيل الدخول'),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('عضو جديد؟ ', style: TextStyle(color: AppColors.textGray)),
                  GestureDetector(
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SignUpScreen())),
                    child: const Text('إنشاء حساب', style: TextStyle(color: AppColors.secondaryCyan, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final majorController = TextEditingController();
  final roleController = TextEditingController();
  File? selectedImage;
  bool isLoading = false;

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: AppColors.statusRed),
    );
  }

  Future<void> _pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 70);
    if (picked != null) {
      setState(() => selectedImage = File(picked.path));
    }
  }

  Future<void> _handleSignUp() async {
    final name = nameController.text.trim();
    final email = emailController.text.trim();
    final password = passwordController.text.trim();
    final major = majorController.text.trim();
    final role = roleController.text.trim();

    if (name.isEmpty || email.isEmpty || password.isEmpty || major.isEmpty || role.isEmpty) {
      _showError('من فضلك املأ جميع البيانات المطلوبة');
      return;
    }
    if (password.length < 6) {
      _showError('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
      return;
    }

    setState(() => isLoading = true);
    try {
      final supabase = Supabase.instance.client;
      final authRes = await supabase.auth.signUp(email: email, password: password);
      final userId = authRes.user!.id;

      String? avatarUrl;
      if (selectedImage != null) {
        final filePath = '$userId.jpg';
        await supabase.storage.from('avatars').upload(filePath, selectedImage!, fileOptions: const FileOptions(upsert: true));
        avatarUrl = supabase.storage.from('avatars').getPublicUrl(filePath);
      }

      await supabase.from('profiles').insert({
        'id': userId,
        'name': name,
        'email': email,
        'major': major,
        'role': role,
        'avatar_url': avatarUrl,
        'status': 'pending',
        'is_admin': false,
      });

      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const PendingApprovalScreen()));
    } on AuthException catch (e) {
      _showError(e.message);
    } catch (e) {
      _showError('حدث خطأ أثناء إنشاء الحساب: $e');
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surfaceWhite,
      appBar: AppBar(title: const Text('انضم لفريق الـ PR')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            GestureDetector(
              onTap: _pickImage,
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  color: AppColors.background,
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.secondaryCyan, width: 2),
                  image: selectedImage != null ? DecorationImage(image: FileImage(selectedImage!), fit: BoxFit.cover) : null,
                ),
                child: selectedImage == null
                    ? const Icon(Icons.camera_alt_rounded, color: AppColors.primaryMagenta, size: 32)
                    : null,
              ),
            ),
            const SizedBox(height: 8),
            const Text('أضف صورتك الشخصية', style: TextStyle(color: AppColors.textGray, fontSize: 13)),
            const SizedBox(height: 24),
            TextField(controller: nameController, decoration: const InputDecoration(hintText: 'الاسم بالكامل *')),
            const SizedBox(height: 14),
            TextField(controller: emailController, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(hintText: 'البريد الإلكتروني *')),
            const SizedBox(height: 14),
            TextField(controller: passwordController, obscureText: true, decoration: const InputDecoration(hintText: 'كلمة المرور (6 أحرف على الأقل) *')),
            const SizedBox(height: 14),
            TextField(controller: majorController, decoration: const InputDecoration(hintText: 'التخصص الدراسي *')),
            const SizedBox(height: 14),
            TextField(controller: roleController, decoration: const InputDecoration(hintText: 'الوظيفة أو الدور المستهدف في القسم *')),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: isLoading ? null : _handleSignUp,
              child: isLoading
                  ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Text('إرسال طلب الانضمام'),
            ),
          ],
        ),
      ),
    );
  }
}

class PendingApprovalScreen extends StatelessWidget {
  final bool isRejected;
  const PendingApprovalScreen({super.key, this.isRejected = false});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surfaceWhite,
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                color: (isRejected ? AppColors.statusRed : AppColors.primaryMagenta).withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                isRejected ? Icons.cancel_outlined : Icons.hourglass_top_rounded,
                size: 64,
                color: isRejected ? AppColors.statusRed : AppColors.primaryMagenta,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              isRejected ? 'عذراً، لم يتم قبول طلبك' : 'طلبك قيد المراجعة',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Text(
              isRejected
                  ? 'يمكنك التواصل مع مشرف القسم لمراجعة بياناتك.'
                  : 'مشرف القسم بيراجع بياناتك حالياً، وهتقدر تدخل للتطبيق أول ما يتم تفعيل حسابك.',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 15, color: AppColors.textGray, height: 1.5),
            ),
            const SizedBox(height: 32),
            OutlinedButton(
              onPressed: () async {
                await Supabase.instance.client.auth.signOut();
                if (!context.mounted) return;
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                  (route) => false,
                );
              },
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(double.infinity, 50),
                side: const BorderSide(color: AppColors.primaryMagenta),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: const Text('تسجيل الخروج', style: TextStyle(color: AppColors.primaryMagenta, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}
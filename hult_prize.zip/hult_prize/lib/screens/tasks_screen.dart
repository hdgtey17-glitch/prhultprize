/*import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class TasksScreen extends StatefulWidget {
  const TasksScreen({super.key});

  @override
  State createState() => _TasksScreenState();
}

class _TasksScreenState extends State {
  String selectedFilter = 'الكل';
  final filters = ['الكل', 'جديدة', 'شغالة', 'خلصت'];

  // قائمة المهام (ستُملأ من Supabase)
  final List tasks = [];

  Color _getStatusColor(String status) {
    switch (status) {
      case 'جديدة':
        return AppColors.primaryMagenta;
      case 'شغالة':
        return AppColors.statusAmber;
      case 'خلصت':
        return AppColors.statusGreen;
      default:
        return AppColors.textGray;
    }
  }

  @override
  Widget build(BuildContext context) {
    final filteredTasks = selectedFilter == 'الكل'
        ? tasks
        : tasks.where((t) => t['status'] == selectedFilter).toList();

    return Column(
      children: [
        Container(
          color: AppColors.surfaceWhite,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: filters.map((filter) {
              final isSelected = selectedFilter == filter;
              return Padding(
                padding: const EdgeInsets.only(left: 8),
                child: ChoiceChip(
                  label: Text(filter),
                  selected: isSelected,
                  onSelected: (_) => setState(() => selectedFilter = filter),
                  selectedColor: AppColors.primaryMagenta,
                  backgroundColor: AppColors.background,
                  labelStyle: TextStyle(
                    color: isSelected ? Colors.white : AppColors.textDark,
                    fontWeight: FontWeight.bold,
                  ),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide.none),
                  showCheckmark: false,
                ),
              );
            }).toList(),
          ),
        ),
        Expanded(
          child: filteredTasks.isEmpty
              ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.task_alt_rounded, size: 56, color: AppColors.textGray),
                      SizedBox(height: 12),
                      Text('لا توجد مهام مسجلة حالياً', style: TextStyle(color: AppColors.textGray, fontSize: 15)),
                    ],
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: filteredTasks.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, idx) {
                    final task = filteredTasks[idx];
                    final statusColor = _getStatusColor(task['status'] ?? 'جديدة');
                    return Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                      child: Text(task['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold)),
                    );
                  },
                ),
        ),
      ],
    );
  }
}*/
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../theme/app_theme.dart';

class TasksScreen extends StatefulWidget {
  final bool isAdmin;
  const TasksScreen({super.key, this.isAdmin = false});

  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> {
  final _supabase = Supabase.instance.client;
  List<dynamic> tasks = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchTasks();
  }

  Future<void> _fetchTasks() async {
    setState(() => isLoading = true);
    try {
      final res = await _supabase
          .from('tasks')
          .select()
          .order('created_at', ascending: false);
      if (mounted) {
        setState(() {
          tasks = List<dynamic>.from(res);
          isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  String _calculateGrade(int totalPoints) {
    if (totalPoints >= 300) return 'عضو قيادي';
    if (totalPoints >= 200) return 'درجة 3';
    if (totalPoints >= 100) return 'درجة 2';
    return 'درجة 1';
  }

  Future<void> _markTaskCompleted(dynamic task) async {
    final user = _supabase.auth.currentUser;
    if (user == null) return;

    final int pointsToAdd = (task['points'] ?? 10) as int;

    try {
      // 1. تحويل حالة المهمة مباشرة إلى معتمدة لمنع تكرار احتساب النقاط
      await _supabase
          .from('tasks')
          .update({'status': 'معتمدة'})
          .eq('id', task['id']);

      // 2. جلب رصيد نقاط المستخدم الحالي وإضافة نقاط المهمة تلقائياً
      final profile = await _supabase
          .from('profiles')
          .select('points, grade')
          .eq('id', user.id)
          .maybeSingle();

      String upgradeNote = '';
      if (profile != null) {
        final int currentPoints = (profile['points'] ?? 0) as int;
        final int newPoints = currentPoints + pointsToAdd;
        final String oldGrade = profile['grade'] ?? 'درجة 1';
        final String newGrade = _calculateGrade(newPoints);

        await _supabase.from('profiles').update({
          'points': newPoints,
          'grade': newGrade,
        }).eq('id', user.id);

        if (newGrade != oldGrade) {
          upgradeNote = ' وتمت ترقيتك إلى $newGrade 🎉';
        }
      }

      _fetchTasks();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('عاش! تم إنجاز المهمة وإضافة +$pointsToAdd نقطة لرصيدك تلقائياً$upgradeNote'),
          backgroundColor: AppColors.statusGreen,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('حدث خطأ: $e'), backgroundColor: AppColors.statusRed),
      );
    }
  }

  Future<void> _deleteTask(String id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف المهمة'),
        content: const Text('هل أنت متأكد من حذف هذه المهمة نهائياً؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف', style: TextStyle(color: AppColors.statusRed)),
          ),
        ],
      ),
    );
    if (confirm != true) return;

    await _supabase.from('tasks').delete().eq('id', id);
    _fetchTasks();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم حذف المهمة بنجاح'), backgroundColor: AppColors.statusGreen),
    );
  }

  Future<void> _editTaskDialog(dynamic task) async {
    final titleCtrl = TextEditingController(text: task['title'] ?? '');
    final detailsCtrl = TextEditingController(text: task['details'] ?? '');
    final assigneeCtrl = TextEditingController(text: task['assigned_to'] ?? '');
    final deadlineCtrl = TextEditingController(text: task['deadline'] ?? '');
    final pointsCtrl = TextEditingController(text: '${task['points'] ?? 10}');

    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تعديل المهمة'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: titleCtrl, decoration: const InputDecoration(hintText: 'عنوان المهمة')),
              const SizedBox(height: 8),
              TextField(controller: detailsCtrl, maxLines: 2, decoration: const InputDecoration(hintText: 'تفاصيل المهمة')),
              const SizedBox(height: 8),
              TextField(controller: assigneeCtrl, decoration: const InputDecoration(hintText: 'المسؤول')),
              const SizedBox(height: 8),
              TextField(controller: deadlineCtrl, decoration: const InputDecoration(hintText: 'الموعد النهائي')),
              const SizedBox(height: 8),
              TextField(
                controller: pointsCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(hintText: 'النقاط المحددة للمهمة'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () async {
              if (titleCtrl.text.trim().isEmpty) return;
              await _supabase.from('tasks').update({
                'title': titleCtrl.text.trim(),
                'details': detailsCtrl.text.trim(),
                'assigned_to': assigneeCtrl.text.trim().isEmpty ? 'الجميع' : assigneeCtrl.text.trim(),
                'deadline': deadlineCtrl.text.trim().isEmpty ? 'قريباً' : deadlineCtrl.text.trim(),
                'points': int.tryParse(pointsCtrl.text.trim()) ?? 10,
              }).eq('id', task['id']);
              if (ctx.mounted) Navigator.pop(ctx, true);
            },
            child: const Text('حفظ التعديل'),
          ),
        ],
      ),
    );

    if (saved == true) {
      _fetchTasks();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم تعديل المهمة بنجاح'), backgroundColor: AppColors.statusGreen),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مهام القسم')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primaryMagenta))
          : tasks.isEmpty
              ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.assignment_turned_in_outlined, size: 56, color: AppColors.textGray),
                      SizedBox(height: 12),
                      Text('لا توجد مهام مسندة حالياً', style: TextStyle(color: AppColors.textGray, fontSize: 15)),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _fetchTasks,
                  color: AppColors.primaryMagenta,
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: tasks.length,
                    separatorBuilder: (_, _) => const SizedBox(height: 12),
                    itemBuilder: (context, index) {
                      final task = tasks[index];
                      final String status = task['status'] ?? 'جديدة';
                      final bool isApproved = status == 'معتمدة';

                      return Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceWhite,
                          borderRadius: BorderRadius.circular(16),
                          border: Border(
                            right: BorderSide(
                              color: isApproved ? AppColors.statusGreen : AppColors.primaryMagenta,
                              width: 4,
                            ),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: (isApproved ? AppColors.statusGreen : AppColors.primaryMagenta).withValues(alpha: 0.12),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    isApproved ? 'تمت واحتُسبت النقاط ✓' : 'متاحة للتنفيذ',
                                    style: TextStyle(
                                      color: isApproved ? AppColors.statusGreen : AppColors.primaryMagenta,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                                Row(
                                  children: [
                                    Text(
                                      '+${task['points'] ?? 10} نقطة',
                                      style: const TextStyle(color: AppColors.accentPurple, fontWeight: FontWeight.bold, fontSize: 13),
                                    ),
                                    if (widget.isAdmin) ...[
                                      IconButton(
                                        icon: const Icon(Icons.edit_outlined, color: AppColors.secondaryCyan, size: 20),
                                        onPressed: () => _editTaskDialog(task),
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.delete_outline_rounded, color: AppColors.statusRed, size: 20),
                                        onPressed: () => _deleteTask(task['id']),
                                      ),
                                    ],
                                  ],
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            Text(task['title'] ?? '', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                            if ((task['details'] ?? '').toString().isNotEmpty) ...[
                              const SizedBox(height: 6),
                              Text(task['details'], style: const TextStyle(color: AppColors.textGray, fontSize: 13)),
                            ],
                            const SizedBox(height: 12),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Text(
                                    'المسؤول: ${task['assigned_to'] ?? 'الجميع'} • ${task['deadline'] ?? ''}',
                                    style: const TextStyle(color: AppColors.textGray, fontSize: 12),
                                  ),
                                ),
                                if (!isApproved)
                                  ElevatedButton.icon(
                                    onPressed: () => _markTaskCompleted(task),
                                    icon: const Icon(Icons.check_circle_outline_rounded, size: 18),
                                    label: const Text('تم التنفيذ', style: TextStyle(fontSize: 13)),
                                    style: ElevatedButton.styleFrom(
                                      minimumSize: const Size(125, 38),
                                      backgroundColor: AppColors.statusGreen,
                                    ),
                                  ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}
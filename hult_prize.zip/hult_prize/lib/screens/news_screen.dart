/*import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class NewsScreen extends StatefulWidget {
  const NewsScreen({super.key});

  @override
  State createState() => _NewsScreenState();
}

class _NewsScreenState extends State {
  // قائمة الأخبار (ستُملأ من Supabase)
  final List newsList = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('أخبار القسم')),
      body: newsList.isEmpty
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.campaign_outlined, size: 56, color: AppColors.textGray),
                  SizedBox(height: 12),
                  Text('لا توجد أخبار منشورة بعد', style: TextStyle(color: AppColors.textGray, fontSize: 15)),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: newsList.length,
              itemBuilder: (context, index) => const SizedBox(),
            ),
    );
  }
}*/


import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../theme/app_theme.dart';

class NewsScreen extends StatefulWidget {
  final bool isAdmin;
  const NewsScreen({super.key, this.isAdmin = false});

  @override
  State<NewsScreen> createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {
  final _supabase = Supabase.instance.client;
  List<dynamic> newsList = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchNews();
  }

  Future<void> _fetchNews() async {
    setState(() => isLoading = true);
    try {
      final res = await _supabase
          .from('news')
          .select()
          .order('created_at', ascending: false);
      if (mounted) {
        setState(() {
          newsList = List<dynamic>.from(res);
          isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> _deleteNews(String id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف الخبر'),
        content: const Text('هل أنت متأكد من حذف هذا الخبر نهائياً؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف', style: TextStyle(color: AppColors.statusRed)),
          ),
        ],
      ),
    );
    if (confirm != true) return;

    try {
      await _supabase.from('news').delete().eq('id', id);
      _fetchNews();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم حذف الخبر بنجاح'), backgroundColor: AppColors.statusGreen),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('خطأ في الحذف: $e'), backgroundColor: AppColors.statusRed),
      );
    }
  }

  Future<void> _editNewsDialog(dynamic item) async {
    final titleCtrl = TextEditingController(text: item['title'] ?? '');
    final bodyCtrl = TextEditingController(text: item['body'] ?? '');

    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تعديل الخبر'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: titleCtrl, decoration: const InputDecoration(hintText: 'عنوان الخبر')),
            const SizedBox(height: 12),
            TextField(controller: bodyCtrl, maxLines: 4, decoration: const InputDecoration(hintText: 'تفاصيل الخبر')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () async {
              if (titleCtrl.text.trim().isEmpty || bodyCtrl.text.trim().isEmpty) return;
              await _supabase.from('news').update({
                'title': titleCtrl.text.trim(),
                'body': bodyCtrl.text.trim(),
              }).eq('id', item['id']);
              if (ctx.mounted) Navigator.pop(ctx, true);
            },
            child: const Text('حفظ التعديل'),
          ),
        ],
      ),
    );

    if (saved == true) {
      _fetchNews();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم تعديل الخبر بنجاح'), backgroundColor: AppColors.statusGreen),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('أخبار القسم')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primaryMagenta))
          : newsList.isEmpty
              ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.campaign_outlined, size: 56, color: AppColors.textGray),
                      SizedBox(height: 12),
                      Text('لا توجد أخبار منشورة بعد', style: TextStyle(color: AppColors.textGray, fontSize: 15)),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _fetchNews,
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: newsList.length,
                    separatorBuilder: (_, _) => const SizedBox(height: 12),
                    itemBuilder: (context, index) {
                      final item = newsList[index];
                      return Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    item['title'] ?? '',
                                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                  ),
                                ),
                                if (widget.isAdmin) ...[
                                  IconButton(
                                    icon: const Icon(Icons.edit_outlined, color: AppColors.secondaryCyan, size: 20),
                                    onPressed: () => _editNewsDialog(item),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.delete_outline_rounded, color: AppColors.statusRed, size: 20),
                                    onPressed: () => _deleteNews(item['id']),
                                  ),
                                ],
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(item['body'] ?? '', style: const TextStyle(color: AppColors.textDark, fontSize: 14, height: 1.5)),
                            const SizedBox(height: 10),
                            Text(
                              'نشر بواسطة: ${item['author_name'] ?? 'مشرف القسم'}',
                              style: const TextStyle(color: AppColors.textGray, fontSize: 12),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}
/*import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State {
  final List joinRequests = [];
  final List reviewTasks = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة تحكم المشرف')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _statCard('${joinRequests.length}', 'طلبات معلقة', AppColors.statusAmber),
                const SizedBox(width: 10),
                _statCard('${reviewTasks.length}', 'مهام للمراجعة', AppColors.primaryMagenta),
                const SizedBox(width: 10),
                _statCard('0%', 'نسبة الحضور', AppColors.secondaryCyan),
              ],
            ),
            const SizedBox(height: 24),
            const Text('طلبات الانضمام الجديدة', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            if (joinRequests.isEmpty)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                child: const Text('لا توجد طلبات انضمام معلقة حالياً', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textGray)),
              ),
            const SizedBox(height: 24),
            const Text('مهام جاهزة للمراجعة', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            if (reviewTasks.isEmpty)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                child: const Text('لا توجد مهام بانتظار المراجعة حالياً', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textGray)),
              ),
          ],
        ),
      ),
    );
  }

  Widget _statCard(String num, String label, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
        child: Column(
          children: [
            Text(num, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: color)),
            const SizedBox(height: 4),
            Text(label, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textGray, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}

class UnifiedCreateScreen extends StatefulWidget {
  const UnifiedCreateScreen({super.key});

  @override
  State createState() => _UnifiedCreateScreenState();
}

class _UnifiedCreateScreenState extends State {
  int selectedType = 0;
  final types = ['خبر', 'ميتنج', 'مهمة', 'جروب'];

  @override
  Widget build(BuildContext context) {
    final activeColor = selectedType == 1 ? AppColors.secondaryCyan : AppColors.primaryMagenta;

    return Scaffold(
      backgroundColor: AppColors.surfaceWhite,
      appBar: AppBar(title: const Text('إضافة جديدة للقسم')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(14)),
              child: Row(
                children: types.asMap().entries.map((entry) {
                  final idx = entry.key;
                  final label = entry.value;
                  final isSelected = selectedType == idx;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () => setState(() => selectedType = idx),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          color: isSelected ? activeColor : Colors.transparent,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(
                          child: Text(
                            label,
                            style: TextStyle(color: isSelected ? Colors.white : AppColors.textGray, fontWeight: FontWeight.bold, fontSize: 13),
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 24),
            if (selectedType == 0) ...[
              const TextField(decoration: InputDecoration(hintText: 'عنوان الخبر')),
              const SizedBox(height: 14),
              const TextField(maxLines: 4, decoration: InputDecoration(hintText: 'تفاصيل الخبر أو الإعلان...')),
            ] else if (selectedType == 1) ...[
              const TextField(decoration: InputDecoration(hintText: 'عنوان الميتنج')),
              const SizedBox(height: 14),
              const TextField(decoration: InputDecoration(hintText: 'التاريخ والوقت')),
              const SizedBox(height: 14),
              const TextField(decoration: InputDecoration(hintText: 'المكان أو رابط الاجتماع')),
            ] else if (selectedType == 2) ...[
              const TextField(decoration: InputDecoration(hintText: 'عنوان المهمة')),
              const SizedBox(height: 14),
              const TextField(maxLines: 3, decoration: InputDecoration(hintText: 'وصف المهمة...')),
              const SizedBox(height: 14),
              const TextField(decoration: InputDecoration(hintText: 'تعيين لـ (عضو أو جروب)')),
              const SizedBox(height: 14),
              const Row(
                children: [
                  Expanded(child: TextField(decoration: InputDecoration(hintText: 'تاريخ التسليم'))),
                  SizedBox(width: 10),
                  Expanded(child: TextField(decoration: InputDecoration(hintText: 'النقاط'))),
                ],
              ),
            ] else ...[
              const TextField(decoration: InputDecoration(hintText: 'اسم الجروب الجديد')),
              const SizedBox(height: 14),
              const TextField(maxLines: 2, decoration: InputDecoration(hintText: 'وصف مهام الجروب')),
            ],
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                // سيتم ربطه بالحفظ في Supabase
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(backgroundColor: activeColor),
              child: Text('نشر / حفظ الـ ${types[selectedType]}'),
            ),
          ],
        ),
      ),
    );
  }
}*/
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../theme/app_theme.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  final _supabase = Supabase.instance.client;
  bool isLoading = true;

  List<dynamic> joinRequests = [];
  List<dynamic> reviewTasks = [];
  dynamic nextMeeting;

  @override
  void initState() {
    super.initState();
    _fetchDashboardData();
  }

  Future<void> _fetchDashboardData() async {
    setState(() => isLoading = true);
    try {
      final pendingRes = await _supabase
          .from('profiles')
          .select()
          .eq('status', 'pending')
          .order('created_at', ascending: false);

      final tasksRes = await _supabase
          .from('tasks')
          .select()
          .eq('status', 'خلصت')
          .order('created_at', ascending: false);

      final meetingsRes = await _supabase
          .from('meetings')
          .select()
          .order('created_at', ascending: false)
          .limit(1);

      if (!mounted) return;
      setState(() {
        joinRequests = List<dynamic>.from(pendingRes);
        reviewTasks = List<dynamic>.from(tasksRes);
        nextMeeting = meetingsRes.isNotEmpty ? meetingsRes.first : null;
        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('حدث خطأ في جلب البيانات: $e'),
          backgroundColor: AppColors.statusRed,
        ),
      );
    }
  }

  Future<void> _handleMemberStatus(String userId, String newStatus, int index) async {
    try {
      await _supabase
          .from('profiles')
          .update({'status': newStatus})
          .eq('id', userId);

      setState(() {
        joinRequests.removeAt(index);
      });

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(newStatus == 'approved'
              ? 'تم قبول العضو وتفعيل حسابه بنجاح!'
              : 'تم رفض طلب الانضمام'),
          backgroundColor:
              newStatus == 'approved' ? AppColors.statusGreen : AppColors.statusRed,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('خطأ: $e'), backgroundColor: AppColors.statusRed),
      );
    }
  }

  String _calculateGrade(int totalPoints) {
    if (totalPoints >= 300) return 'عضو قيادي';
    if (totalPoints >= 200) return 'درجة 3';
    if (totalPoints >= 100) return 'درجة 2';
    return 'درجة 1';
  }

  Future<void> _approveTaskAndAddPoints(dynamic task, int index) async {
    final int pointsToAdd = (task['points'] ?? 10) as int;
    final String assignedTo = (task['assigned_to'] ?? '').toString().trim();

    try {
      await _supabase
          .from('tasks')
          .update({'status': 'معتمدة'})
          .eq('id', task['id']);

      String upgradeNote = '';
      if (assignedTo.isNotEmpty) {
        final memberRes = await _supabase
            .from('profiles')
            .select('id, points, grade')
            .ilike('name', '%$assignedTo%')
            .maybeSingle();

        if (memberRes != null) {
          final int currentPoints = (memberRes['points'] ?? 0) as int;
          final int newPoints = currentPoints + pointsToAdd;
          final String oldGrade = memberRes['grade'] ?? 'درجة 1';
          final String newGrade = _calculateGrade(newPoints);

          await _supabase.from('profiles').update({
            'points': newPoints,
            'grade': newGrade,
          }).eq('id', memberRes['id']);

          if (newGrade != oldGrade) {
            upgradeNote = ' وتمت ترقيته إلى $newGrade 🎉';
          }
        }
      }

      setState(() {
        reviewTasks.removeAt(index);
      });

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('تم اعتماد المهمة ومنح $pointsToAdd نقطة$upgradeNote'),
          backgroundColor: AppColors.statusGreen,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('خطأ أثناء الاعتماد: $e'), backgroundColor: AppColors.statusRed),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final List goingList = nextMeeting != null ? (nextMeeting['going_users'] ?? []) : [];
    final List notGoingList = nextMeeting != null ? (nextMeeting['not_going_users'] ?? []) : [];
    final int totalVotes = goingList.length + notGoingList.length;
    final int attendancePercent =
        totalVotes == 0 ? 0 : ((goingList.length / totalVotes) * 100).round();

    return Scaffold(
      appBar: AppBar(
        title: const Text('لوحة تحكم المشرف'),
        actions: [
          IconButton(
            onPressed: _fetchDashboardData,
            icon: const Icon(Icons.refresh_rounded, color: AppColors.secondaryCyan),
            tooltip: 'تحديث البيانات',
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primaryMagenta))
          : RefreshIndicator(
              onRefresh: _fetchDashboardData,
              color: AppColors.primaryMagenta,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        _statCard('${joinRequests.length}', 'طلبات معلقة', AppColors.statusAmber),
                        const SizedBox(width: 10),
                        _statCard('${reviewTasks.length}', 'مهام للمراجعة', AppColors.primaryMagenta),
                        const SizedBox(width: 10),
                        _statCard('$attendancePercent%', 'نسبة الحضور', AppColors.secondaryCyan),
                      ],
                    ),
                    const SizedBox(height: 24),
                    const Text('طلبات الانضمام الجديدة', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    if (joinRequests.isEmpty)
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                        child: const Text('لا توجد طلبات انضمام معلقة حالياً', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textGray)),
                      )
                    else
                      ...joinRequests.asMap().entries.map((entry) {
                        final idx = entry.key;
                        final req = entry.value;
                        final String name = req['name'] ?? 'عضو جديد';
                        final String? avatarUrl = req['avatar_url'];

                        return Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  CircleAvatar(
                                    backgroundColor: AppColors.secondaryCyan.withValues(alpha: 0.15),
                                    backgroundImage: avatarUrl != null && avatarUrl.isNotEmpty
                                        ? NetworkImage(avatarUrl)
                                        : null,
                                    child: avatarUrl == null || avatarUrl.isEmpty
                                        ? Text(
                                            name.isNotEmpty ? name.substring(0, 1) : 'ع',
                                            style: const TextStyle(color: AppColors.secondaryCyan, fontWeight: FontWeight.bold),
                                          )
                                        : null,
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                                        Text('${req['major'] ?? ''} • ${req['role'] ?? ''}', style: const TextStyle(color: AppColors.textGray, fontSize: 12)),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  Expanded(
                                    child: ElevatedButton(
                                      onPressed: () => _handleMemberStatus(req['id'], 'approved', idx),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: AppColors.statusGreen,
                                        minimumSize: const Size(0, 38),
                                      ),
                                      child: const Text('قبول', style: TextStyle(fontSize: 13)),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: OutlinedButton(
                                      onPressed: () => _handleMemberStatus(req['id'], 'rejected', idx),
                                      style: OutlinedButton.styleFrom(
                                        foregroundColor: AppColors.statusRed,
                                        side: const BorderSide(color: AppColors.statusRed),
                                        minimumSize: const Size(0, 38),
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                                      ),
                                      child: const Text('رفض', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      }),
                    const SizedBox(height: 24),
                    const Text('مهام جاهزة للمراجعة', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    if (reviewTasks.isEmpty)
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                        child: const Text('لا توجد مهام بانتظار المراجعة حالياً', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textGray)),
                      )
                    else
                      ...reviewTasks.asMap().entries.map((entry) {
                        final idx = entry.key;
                        final task = entry.value;
                        return Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    task['assigned_to'] ?? 'عضو',
                                    style: const TextStyle(color: AppColors.secondaryCyan, fontWeight: FontWeight.bold, fontSize: 12),
                                  ),
                                  Text(
                                    '${task['points'] ?? 10} نقطة',
                                    style: const TextStyle(color: AppColors.primaryMagenta, fontWeight: FontWeight.bold, fontSize: 12),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 6),
                              Text(task['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                              const SizedBox(height: 12),
                              ElevatedButton.icon(
                                onPressed: () => _approveTaskAndAddPoints(task, idx),
                                icon: const Icon(Icons.verified_rounded, size: 18),
                                label: const Text('اعتماد ومنح النقاط', style: TextStyle(fontSize: 13)),
                                style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 40)),
                              ),
                            ],
                          ),
                        );
                      }),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _statCard(String num, String label, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        decoration: BoxDecoration(color: AppColors.surfaceWhite, borderRadius: BorderRadius.circular(16)),
        child: Column(
          children: [
            Text(num, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: color)),
            const SizedBox(height: 4),
            Text(label, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textGray, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}

class UnifiedCreateScreen extends StatefulWidget {
  const UnifiedCreateScreen({super.key});

  @override
  State<UnifiedCreateScreen> createState() => _UnifiedCreateScreenState();
}

class _UnifiedCreateScreenState extends State<UnifiedCreateScreen> {
  final _supabase = Supabase.instance.client;
  int selectedType = 0;
  final types = ['خبر', 'ميتنج', 'مهمة', 'جروب'];
  bool isSaving = false;

  final newsTitleCtrl = TextEditingController();
  final newsContentCtrl = TextEditingController();

  final meetingTitleCtrl = TextEditingController();
  final meetingDateCtrl = TextEditingController();
  final meetingLocationCtrl = TextEditingController();

  final taskTitleCtrl = TextEditingController();
  final taskDescCtrl = TextEditingController();
  final taskDeadlineCtrl = TextEditingController();
  final taskPointsCtrl = TextEditingController(text: '10');

  // قائمة المسؤولين (الجميع + الجروبات + الأعضاء)
  List<String> assigneeOptions = ['الجميع'];
  String selectedAssignee = 'الجميع';

  final groupNameCtrl = TextEditingController();
  final groupDescCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadAssignees();
  }

  Future<void> _loadAssignees() async {
    try {
      final groupsRes = await _supabase.from('groups').select('name').order('name');
      final membersRes = await _supabase
          .from('profiles')
          .select('name')
          .eq('status', 'approved')
          .order('name');

      final List<String> options = ['الجميع'];

      for (final g in groupsRes) {
        final gName = (g['name'] ?? '').toString().trim();
        if (gName.isNotEmpty) {
          options.add('جروب: $gName');
        }
      }

      for (final m in membersRes) {
        final mName = (m['name'] ?? '').toString().trim();
        if (mName.isNotEmpty && !options.contains(mName)) {
          options.add(mName);
        }
      }

      if (mounted) {
        setState(() {
          assigneeOptions = options;
          if (!assigneeOptions.contains(selectedAssignee)) {
            selectedAssignee = 'الجميع';
          }
        });
      }
    } catch (_) {}
  }

  void _showMsg(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: isError ? AppColors.statusRed : AppColors.statusGreen,
      ),
    );
  }

  Future<void> _handleSave() async {
    setState(() => isSaving = true);
    try {
      final user = _supabase.auth.currentUser;
      String authorName = 'مشرف القسم';

      if (user != null) {
        final profile = await _supabase
            .from('profiles')
            .select('name')
            .eq('id', user.id)
            .maybeSingle();
        if (profile != null && profile['name'] != null) {
          authorName = profile['name'];
        }
      }

      if (selectedType == 0) {
        if (newsTitleCtrl.text.trim().isEmpty || newsContentCtrl.text.trim().isEmpty) {
          _showMsg('من فضلك أدخل عنوان الخبر وتفاصيله', isError: true);
          setState(() => isSaving = false);
          return;
        }
        await _supabase.from('news').insert({
          'title': newsTitleCtrl.text.trim(),
          'body': newsContentCtrl.text.trim(),
          'author_name': authorName,
        });
      } else if (selectedType == 1) {
        if (meetingTitleCtrl.text.trim().isEmpty || meetingDateCtrl.text.trim().isEmpty) {
          _showMsg('من فضلك أدخل عنوان الميتنج وتوقيته', isError: true);
          setState(() => isSaving = false);
          return;
        }
        await _supabase.from('meetings').insert({
          'title': meetingTitleCtrl.text.trim(),
          'meeting_time': meetingDateCtrl.text.trim(),
          'location': meetingLocationCtrl.text.trim().isEmpty
              ? 'أونلاين'
              : meetingLocationCtrl.text.trim(),
        });
      } else if (selectedType == 2) {
        if (taskTitleCtrl.text.trim().isEmpty) {
          _showMsg('من فضلك أدخل عنوان المهمة', isError: true);
          setState(() => isSaving = false);
          return;
        }
        // إزالة كلمة "جروب: " عند الحفظ لتطابق اسم الجروب في صفحة تفاصيل الجروب
        final cleanAssignee = selectedAssignee.startsWith('جروب: ')
            ? selectedAssignee.replaceFirst('جروب: ', '')
            : selectedAssignee;

        await _supabase.from('tasks').insert({
          'title': taskTitleCtrl.text.trim(),
          'details': taskDescCtrl.text.trim(),
          'assigned_to': cleanAssignee,
          'deadline': taskDeadlineCtrl.text.trim().isEmpty
              ? 'قريباً'
              : taskDeadlineCtrl.text.trim(),
          'points': int.tryParse(taskPointsCtrl.text.trim()) ?? 10,
          'status': 'جديدة',
        });
      } else {
        if (groupNameCtrl.text.trim().isEmpty) {
          _showMsg('من فضلك أدخل اسم الجروب', isError: true);
          setState(() => isSaving = false);
          return;
        }
        await _supabase.from('groups').insert({
          'name': groupNameCtrl.text.trim(),
          'description': groupDescCtrl.text.trim(),
        });
      }

      if (!mounted) return;
      _showMsg('تم نشر / حفظ الـ ${types[selectedType]} بنجاح!');
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      _showMsg('حدث خطأ أثناء الحفظ: $e', isError: true);
    } finally {
      if (mounted) setState(() => isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final activeColor = selectedType == 1 ? AppColors.secondaryCyan : AppColors.primaryMagenta;

    return Scaffold(
      backgroundColor: AppColors.surfaceWhite,
      appBar: AppBar(title: const Text('إضافة جديدة للقسم')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(14)),
              child: Row(
                children: types.asMap().entries.map((entry) {
                  final idx = entry.key;
                  final label = entry.value;
                  final isSelected = selectedType == idx;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () => setState(() => selectedType = idx),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          color: isSelected ? activeColor : Colors.transparent,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(
                          child: Text(
                            label,
                            style: TextStyle(color: isSelected ? Colors.white : AppColors.textGray, fontWeight: FontWeight.bold, fontSize: 13),
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 24),
            if (selectedType == 0) ...[
              TextField(controller: newsTitleCtrl, decoration: const InputDecoration(hintText: 'عنوان الخبر')),
              const SizedBox(height: 14),
              TextField(controller: newsContentCtrl, maxLines: 4, decoration: const InputDecoration(hintText: 'تفاصيل الخبر أو الإعلان...')),
            ] else if (selectedType == 1) ...[
              TextField(controller: meetingTitleCtrl, decoration: const InputDecoration(hintText: 'عنوان الميتنج')),
              const SizedBox(height: 14),
              TextField(controller: meetingDateCtrl, decoration: const InputDecoration(hintText: 'التاريخ والوقت (مثال: الخميس 8 م)')),
              const SizedBox(height: 14),
              TextField(controller: meetingLocationCtrl, decoration: const InputDecoration(hintText: 'المكان أو رابط الاجتماع')),
            ] else if (selectedType == 2) ...[
              TextField(controller: taskTitleCtrl, decoration: const InputDecoration(hintText: 'عنوان المهمة')),
              const SizedBox(height: 14),
              TextField(controller: taskDescCtrl, maxLines: 3, decoration: const InputDecoration(hintText: 'وصف المهمة...')),
              const SizedBox(height: 14),
              const Text('تعيين المهمة لـ:', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.textGray)),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                initialValue: selectedAssignee,
                isExpanded: true,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: AppColors.background,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                  prefixIcon: const Icon(Icons.assignment_ind_outlined, color: AppColors.primaryMagenta),
                ),
                items: assigneeOptions.map((option) {
                  return DropdownMenuItem<String>(
                    value: option,
                    child: Text(option, overflow: TextOverflow.ellipsis),
                  );
                }).toList(),
                onChanged: (val) {
                  if (val != null) {
                    setState(() => selectedAssignee = val);
                  }
                },
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(child: TextField(controller: taskDeadlineCtrl, decoration: const InputDecoration(hintText: 'تاريخ التسليم'))),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextField(
                      controller: taskPointsCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(hintText: 'النقاط'),
                    ),
                  ),
                ],
              ),
            ] else ...[
              TextField(controller: groupNameCtrl, decoration: const InputDecoration(hintText: 'اسم الجروب الجديد')),
              const SizedBox(height: 14),
              TextField(controller: groupDescCtrl, maxLines: 2, decoration: const InputDecoration(hintText: 'وصف مهام الجروب')),
            ],
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: isSaving ? null : _handleSave,
              style: ElevatedButton.styleFrom(backgroundColor: activeColor),
              child: isSaving
                  ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : Text('نشر / حفظ الـ ${types[selectedType]}'),
            ),
          ],
        ),
      ),
    );
  }
}